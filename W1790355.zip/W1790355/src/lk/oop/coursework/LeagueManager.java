package lk.oop.coursework;

public interface LeagueManager {

    void addClub();
    void deleteClub();
    void displayStatics();
    void tableDisplaying();
    void addMatch();
    void randomMatch();
}
